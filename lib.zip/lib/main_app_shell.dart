import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:intl/intl.dart';
import 'services/alarm_service.dart';
import 'utils/snackbar_utils.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'providers/family/family_group_provider.dart';
import 'providers/family/family_alerts_provider.dart';

import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models/medicine_model.dart';
import 'screens/alarm_setup_screen.dart';
import 'screens/family/family_hub_v2_screen.dart';
import 'screens/vitals_screen.dart';
import 'main.dart' show activeAlarmIdNotifier, activeSlotAlarmNotifier, medicineUpdatedNotifier;
import 'meds_screen.dart';
import 'screens/more_screen.dart';
import 'settings_screen.dart';
import 'screens/notification_inbox_screen.dart';
import 'screens/health/health_hub_screen.dart';
import 'services/activity_service.dart';
import 'services/notification_service.dart';
import 'services/slot_preferences_service.dart';
import 'services/offline_sync_service.dart';
import 'screens/group_alarm_screen.dart';
import 'screens/appointment_screen.dart';
import 'screens/health/records_screen.dart';
import 'models/achievement.dart';
import 'widgets/achievement_dialog.dart';
import 'services/gamification_service.dart';

import 'screens/achievements_screen.dart';
import 'screens/meds/widgets/refill_center_sheet.dart';
import 'screens/health/record_upload_sheet.dart';

// ==========================================
// 1. MAIN APP SHELL (Navigation + Alarm Logic)
// ==========================================
class MainAppShell extends StatefulWidget {
  const MainAppShell({super.key});

  @override
  State<MainAppShell> createState() => _MainAppShellState();
}

class _MainAppShellState extends State<MainAppShell> {
  int _currentIndex = 0;
  int _homeRefreshVersion = 0;
  
  final _supabase = Supabase.instance.client;
  int _pendingMedsCount = 0;
  StreamSubscription? _medsSubscription;
  StreamSubscription<List<ConnectivityResult>>? _connectivitySubscription;
  bool _isOffline = false;

  @override
  void initState() {
    super.initState();

    // Listen for medication changes to update badge
    _setupMedsSubscription();
    _updatePendingMedsCount();
    _checkFirstLaunchPermissions();
    _setupConnectivity();
  }

  void _setupConnectivity() {
    _connectivitySubscription = Connectivity().onConnectivityChanged.listen((results) {
      if (mounted) {
        setState(() {
          _isOffline = !results.contains(ConnectivityResult.wifi) && 
                       !results.contains(ConnectivityResult.mobile);
        });
      }
    });
  }

  List<Widget> _buildPages() {
    return [
      HomeScreen(
        key: ValueKey('home_$_homeRefreshVersion'),
        onTabChange: (index) => setState(() => _currentIndex = index),
      ),
      const MedsScreen(),
      const HealthHubScreen(),
      const FamilyHubV2Screen(),
      const MoreScreen(),
    ];
  }

  void _setupMedsSubscription() {
    final userId = _supabase.auth.currentUser?.id;
    if (userId == null) return;

    _medsSubscription = _supabase
        .from('medications')
        .stream(primaryKey: ['id'])
        .eq('user_id', userId)
        .listen(
          (_) => _updatePendingMedsCount(),
          onError: (e) => debugPrint('Meds stream error: $e'),
        );
  }

  Future<void> _updatePendingMedsCount() async {
    try {
      final userId = _supabase.auth.currentUser?.id;
      if (userId == null) return;

      final today = DateTime.now().toIso8601String().split('T')[0];
      
      // ✅ Aaj ke active medicines count karo
      final response = await _supabase
          .from('medications')
          .select('id')
          .eq('user_id', userId)
          .eq('is_active', true)
          .lte('start_date', today)
          .gte('end_date', today);
      
      if (mounted) {
        setState(() {
          _pendingMedsCount = (response as List).length;
        });
      }
    } catch (e) {
      debugPrint("Error updating pending meds count: $e");
    }
  }

  Future<void> _checkFirstLaunchPermissions() async {
    final prefs = await SharedPreferences.getInstance();
    final setupDone = prefs.getBool('alarm_setup_done') ?? false;

    if (!setupDone) {
      final notif = await Permission.notification.isGranted;
      final exact = await Permission.scheduleExactAlarm.isGranted;
      final battery = await Permission.ignoreBatteryOptimizations.isGranted;

      if (!notif || !exact || !battery) {
        await Future.delayed(const Duration(milliseconds: 800));
        if (mounted) {
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const AlarmSetupScreen(showAsOnboarding: true),
            ),
          );
          await prefs.setBool('alarm_setup_done', true);
        }
      } else {
        await prefs.setBool('alarm_setup_done', true);
      }
    }
  }

  @override
  void dispose() {
    _medsSubscription?.cancel();
    _connectivitySubscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = _buildPages();

    return Scaffold(
      body: Column(
        children: [
          if (_isOffline)
            Container(
              width: double.infinity,
              color: Colors.orange[800],
              padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 8, bottom: 8),
              child: const Text(
                'Offline - Changes will sync when connected',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold),
              ),
            ),
          Expanded(child: IndexedStack(index: _currentIndex, children: pages)),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: const Color(0xFF0EA5E9),
        unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed,
        onTap: (index) => setState(() {
          if (index == 0 && _currentIndex != 0) {
            _homeRefreshVersion++;
          }
          _currentIndex = index;
        }),
        items: [
          const BottomNavigationBarItem(icon: Icon(LucideIcons.home), label: 'Home'),
          BottomNavigationBarItem(
            icon: Badge(
              label: Text(_pendingMedsCount.toString()),
              isLabelVisible: _pendingMedsCount > 0,
              child: const Icon(LucideIcons.pill),
            ),
            label: 'Meds',
          ),
          const BottomNavigationBarItem(icon: Icon(LucideIcons.activity), label: 'Health'),
          const BottomNavigationBarItem(icon: Icon(LucideIcons.users), label: 'Family'),
          const BottomNavigationBarItem(icon: Icon(LucideIcons.moreHorizontal), label: 'More'),
        ],
      ),
    );
  }
}

// ==========================================
// 2. HOME SCREEN (Dashboard UI)
// ==========================================
class HomeScreen extends StatefulWidget {
  final Function(int) onTabChange;
  const HomeScreen({super.key, required this.onTabChange});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _supabase = Supabase.instance.client;
  final _alarmService = AlarmService();
  String? _fullName;
  bool _isLoading = true;
  bool _isRefreshingDashboard = false;
  List<Medicine> _allMeds = [];
  List<Medicine> _todaysMeds = [];
  final Set<String> _existingImagePaths = {};
  Map<String, dynamic>? _latestVital;

  // New state variables for Quick Stats
  int _totalMedsToday = 0;
  int _takenMedsToday = 0;
  int _familyCount = 0;
  int _streakDays = 0;

  // Next Medication Data
  Map<String, dynamic>? _nextMedData;
  String? _nextMedTimeLabel;

  // Missed Medicines (last 7 days)
  List<Map<String, dynamic>> _missedLogs = [];

  // Next Appointment
  Map<String, dynamic>? _nextAppointment;
  List<Map<String, dynamic>> _todaysAppointments = [];
  List<Map<String, dynamic>> _todaysTasks = [];

  // FIX 3: Due Soon animated list
  final GlobalKey<AnimatedListState> _dueSoonListKey = GlobalKey<AnimatedListState>();
  List<Map<String, dynamic>> _cachedDueSoon = [];

  // Quick Action refresh + local slot tracking
  Timer? _minuteTimer;
  StreamSubscription? _medsSubscription;
  final Set<String> _takenSlotIdsToday = {};
  final Set<String> _skippedSlotIds = {}; // Format: "medId_slot"
  Map<String, dynamic> _slotPrefs = {};
  final ScrollController _scrollController = ScrollController();
  // PHASE 2: Failed alarm warnings (from alarm_set_failures prefs)
  List<Map<String, dynamic>> _failedAlarmWarnings = [];

  @override
  void initState() {
    super.initState();
    _initDashboard()
        .then((_) => _reconcileGroupAlarms())
        .then((_) => _rescheduleAllTodayAlarms());
    _setupMedsSubscription();
    _minuteTimer = Timer.periodic(const Duration(minutes: 1), (timer) {
      if (mounted) {
        final now = DateTime.now();
        _initDashboard();
        _checkSlotWhatsAppReminders();
        _checkSlotEnds();
        if (now.hour == 0 && now.minute == 0) {
          _rescheduleAllTodayAlarms();
        }
        _cachedDueSoon = _getDueSoonMeds();
        setState(() {});
      }
    });
    // Refresh Due Soon panel when medicine alarm time is edited
    medicineUpdatedNotifier.addListener(_onMedicineUpdated);
    activeSlotAlarmNotifier.addListener(_onSlotAlarmReceived);

    // One-time slot setup prompt
    _checkSlotSetupPrompt();
    _checkBootReschedule();
  }

  void _onMedicineUpdated() async {
    if (mounted) {
      await Future.delayed(const Duration(milliseconds: 500));
      _isRefreshingDashboard = false; // Reset guard so refresh isn't skipped
      await _initDashboard();
      await _rescheduleAllTodayAlarms();
    }
  }
  Future<void> _checkStreakCelebration(int streak) async {
    if (streak == 0) return;
    final milestones = [1, 3, 7, 14, 30, 60, 100, 365];
    if (!milestones.contains(streak)) return;

    final prefs = await SharedPreferences.getInstance();
    final lastCelebrated = prefs.getInt('last_celebrated_streak') ?? 0;
    
    if (streak > lastCelebrated) {
      await prefs.setInt('last_celebrated_streak', streak);
      
      // Find the achievement
      Achievement? unlockedBadge;
      for (final badge in Achievement.availableBadges) {
        if (badge.requiredStreak == streak) {
          unlockedBadge = badge;
          break;
        }
      }

      if (unlockedBadge != null) {
        // Unlock via GamificationService
        final unlocked = await GamificationService.instance.unlockAchievement(unlockedBadge.id);

        if (unlocked && mounted) {
          showDialog(
            context: context,
            barrierDismissible: false,
            builder: (_) => AchievementDialog(achievement: unlockedBadge!),
          );
        }
      }
    }
  }

  void _onSlotAlarmReceived() {
    final slotKey = activeSlotAlarmNotifier.value;
    if (slotKey == null || !mounted) return;

    // ✅ Scroll to top so Due Soon panel is visible
    if (_scrollController.hasClients) {
      _scrollController.animateTo(0,
          duration: const Duration(milliseconds: 400),
          curve: Curves.easeOut);
    }

    // ✅ Check alarm style preference
    _openGroupAlarmUI(slotKey);
    activeSlotAlarmNotifier.value = null;
  }

  /// FIX 4: Shows one AlarmScreen per medicine in the slot, sequentially.
  /// Previously only the FIRST medicine's ID was passed, so only one was ever
  /// logged as taken — the rest silently disappeared. Now every medicine gets
  /// its own AlarmScreen interaction (user confirms each one).
  Future<void> _openGroupAlarmUI(String slotKey) async {
    final prefs = await SharedPreferences.getInstance();
    final fullscreen = prefs.getBool('alarm_style_fullscreen') ?? true;

    if (!fullscreen || !mounted) {
      setState(() {});
      return;
    }

    // Build the pending list — medicines in this slot not yet taken/skipped
    List<Medicine> medsForSlot = _todaysMeds.where((m) {
      if (!m.isActive || m.isPaused || !m.isActiveOnDate(DateTime.now())) return false;
      final slotIdx = _slotIndex(slotKey.startsWith('custom') ? 'custom' : slotKey);
      final slotId = _slotKey(m.id ?? '', slotIdx);
      return !_takenSlotIdsToday.contains(slotId) &&
             !_skippedSlotIds.contains(slotId) &&
             (m.slotTypes.contains(slotKey) || slotKey.startsWith('custom'));
    }).toList();

    if (medsForSlot.isEmpty || !mounted) return;

    final alarmId = activeAlarmIdNotifier.value ?? 0;

    // PHASE 2: Open GroupAlarmScreen directly
    final takenIds = await Navigator.of(context).push<List<String>>(
      MaterialPageRoute(
        builder: (_) => GroupAlarmScreen(
          alarmId: alarmId,
        ),
      ),
    );

    // If returned non-null, process the results
    if (takenIds != null && mounted) {
      setState(() {
        for (var med in medsForSlot) {
          if (med.id != null) {
            final slotId = _slotKey(med.id!, _slotIndex(slotKey.startsWith('custom') ? 'custom' : slotKey));
            if (takenIds.contains(med.id)) {
              _takenSlotIdsToday.add(slotId);
            } else if (takenIds.isEmpty) {
              // If empty list returned, it means "Skip All Today" was tapped
              _skippedSlotIds.add(slotId);
            }
          }
        }
        _cachedDueSoon = _getDueSoonMeds();
      });
    }

    if (mounted) setState(() {});
  }

  Future<void> _checkBootReschedule() async {
    final prefs = await SharedPreferences.getInstance();
    final needsReschedule = prefs.getBool('needs_reschedule') ?? false;
    final needsWmReschedule = prefs.getBool('needs_alarm_reschedule_on_open') ?? false;
    
    if (!needsReschedule && !needsWmReschedule) return;

    debugPrint('Rescheduling alarms on boot/open (flags: needs_reschedule=$needsReschedule, wm_reschedule=$needsWmReschedule)');
    await _initDashboard();
    await _rescheduleAllTodayAlarms();
    await prefs.setBool('needs_reschedule', false);
    await prefs.setBool('needs_alarm_reschedule_on_open', false);
  }

  /// Helper to map existing group alarm prefs -> DB `alarm_id1`
  Future<void> _reconcileGroupAlarms() async {
    final prefs = await SharedPreferences.getInstance();
    final keys = prefs.getKeys().where((k) => k.startsWith('group_alarm_') && !k.startsWith('active_group_alarm_'));
    
    for (final key in keys) {
      try {
        final data = jsonDecode(prefs.getString(key) ?? '{}');
        final isRetry = data['is_retry'] == true;
        if (isRetry) continue; // Only map primary group alarms

        final alarmIdStr = key.replaceFirst('group_alarm_', '');
        final alarmId = int.tryParse(alarmIdStr);
        if (alarmId == null) continue;

        final medIds = List<String>.from(data['medication_ids'] ?? []);
        if (medIds.isNotEmpty) {
          await _supabase.from('medications').update({
            'alarm_id1': alarmId
          }).inFilter('id', medIds);
        }
      } catch (e) {
        debugPrint('Reconciliation error for key $key: $e');
      }
    }
    debugPrint('Migration: Reconciled group alarm prefs -> DB.');
  }

  Future<void> _rescheduleAllTodayAlarms() async {
    final today = DateTime.now();
    final prefs = await SharedPreferences.getInstance();
    final slotPrefs = await SlotPreferencesService().getPreferences();
    final slotGroups = <String, List<Medicine>>{};

    for (final med in _allMeds) {
      if (!med.isActive || med.isPaused || !med.isActiveOnDate(today)) continue;

      for (final slot in med.slotTypes) {
        if (slot == 'custom') {
          for (int i = 0; i < med.customTimes.length; i++) {
            final alarmTime = _parseMedicineTimeForDate(med.customTimes[i], today);
            if (alarmTime == null || alarmTime.isBefore(today)) continue;
            slotGroups.putIfAbsent('custom_${med.id}_$i', () => []).add(med);
          }
        } else {
          final alarmTime = _getSlotAlarmTime(slot, med, today, slotPrefs);
          if (alarmTime.isBefore(today)) continue;
          slotGroups.putIfAbsent(slot, () => []).add(med);
        }
      }
    }

    for (final entry in slotGroups.entries) {
      final slotKey = entry.key;
      final meds = entry.value;
      final slot = slotKey.startsWith('custom') ? 'custom' : slotKey;
      final alarmTime = _getSlotAlarmTime(slotKey, meds.first, today, slotPrefs);

      await _alarmService.cancelSlotAlarms(slotKey);
      final alarmId = await _alarmService.scheduleGroupSlotAlarm(
        slot: slot,
        slotKey: slotKey,
        alarmTime: alarmTime,
        medicineNames: meds.map((m) => m.name).toList(),
        medicationIds: meds.map((m) => m.id).whereType<String>().toList(),
        dosages: meds.map((m) => m.getCurrentDosage(alarmTime)).toList(),
      );

      if (alarmId != null) {
        await prefs.setInt('active_group_alarm_$slotKey', alarmId);
        
        final medIds = meds.map((m) => m.id).whereType<String>().toList();
        if (medIds.isNotEmpty) {
          try {
            await _supabase.from('medications').update({
              'alarm_id1': alarmId
            }).inFilter('id', medIds);
          } catch (e) {
            debugPrint('Failed to sync group alarm IDs to Supabase: $e');
          }
        }
      }
    }
  }

  DateTime _getSlotAlarmTime(
    String slotKey,
    Medicine med,
    DateTime date,
    Map<String, dynamic> slotPrefs,
  ) {
    if (slotKey.startsWith('custom')) {
      final idx = int.tryParse(slotKey.split('_').last) ?? 0;
      if (idx < med.customTimes.length) {
        return _parseMedicineTimeForDate(med.customTimes[idx], date) ??
            DateTime(date.year, date.month, date.day, 8);
      }
    }

    final startStr = slotPrefs['${slotKey}_start'] ?? _defaultSlotStart(slotKey);
    final parts = startStr.split(':');
    return DateTime(
      date.year,
      date.month,
      date.day,
      int.tryParse(parts[0]) ?? 8,
      parts.length > 1 ? int.tryParse(parts[1]) ?? 0 : 0,
    );
  }

  DateTime? _parseMedicineTimeForDate(String timeStr, DateTime date) {
    final trimmed = timeStr.trim();
    // Try 24-hour format first (HH:mm or HH:mm:ss) — this is what the DB stores
    final parts = trimmed.split(':');
    if (parts.length >= 2) {
      final hour = int.tryParse(parts[0]);
      final minute = int.tryParse(parts[1]);
      if (hour != null && minute != null && hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59) {
        return DateTime(date.year, date.month, date.day, hour, minute);
      }
    }
    // Fallback: try 12-hour AM/PM format (legacy data)
    try {
      final parsed = DateFormat('hh:mm a').parseStrict(trimmed);
      return DateTime(date.year, date.month, date.day, parsed.hour, parsed.minute);
    } catch (_) {
      return null;
    }
  }

  Future<void> _checkAndScheduleRetry(String slotKey) async {
    final slot = slotKey.startsWith('custom') ? 'custom' : slotKey;
    final slotPrefs = await SlotPreferencesService().getPreferences();
    final retryInterval =
        int.tryParse(slotPrefs['retry_interval']?.toString() ?? '30') ?? 30;

    await _alarmService.cancelSlotAlarms(slotKey);

    final remaining = _getDueSoonMeds()
        .where((m) => (m['slotKey'] as String?) == slotKey)
        .toList();
    if (remaining.isEmpty) {
      debugPrint('All $slotKey medicines taken - no retry');
      return;
    }

    final retryTime = DateTime.now().add(Duration(minutes: retryInterval));
    final slotEnd = _getSlotEndDateTime(slotKey, DateTime.now());
    if (retryTime.isAfter(slotEnd)) {
      await _markSlotRemainingAsMissed(slotKey);
      return;
    }

    final retryId = await _alarmService.scheduleRetryAlarm(
      slot: slot,
      slotKey: slotKey,
      retryTime: retryTime,
      originalScheduledTime: remaining.first['dateTime'] as DateTime,
      remainingMedicineNames:
          remaining.map((m) => (m['medicine'] as Medicine).name).toList(),
      remainingMedicationIds:
          remaining.map((m) => (m['medicine'] as Medicine).id).whereType<String>().toList(),
      remainingDosages:
          remaining.map((m) => (m['medicine'] as Medicine).getCurrentDosage(retryTime)).toList(),
    );

    final prefs = await SharedPreferences.getInstance();
    if (retryId != null) {
      await prefs.setInt('active_retry_alarm_$slotKey', retryId);
    }
  }

  void _checkSlotEnds() async {
    final now = DateTime.now();
    final allSlotKeys = <String>{};

    for (final med in _allMeds) {
      if (!med.isActive || med.isPaused || !med.isActiveOnDate(now)) continue;
      for (final slot in med.slotTypes) {
        if (slot == 'custom') {
          for (int i = 0; i < med.customTimes.length; i++) {
            allSlotKeys.add('custom_${med.id}_$i');
          }
        } else {
          allSlotKeys.add(slot);
        }
      }
    }

    final prefs = await SharedPreferences.getInstance();
    final dayKey = DateFormat('yyyyMMdd').format(now);
    for (final slotKey in allSlotKeys) {
      final slotEnd = _getSlotEndDateTime(slotKey, now);
      if (now.isAfter(slotEnd.add(const Duration(minutes: 2)))) {
        final alreadyMarked = prefs.getBool('slot_missed_${slotKey}_$dayKey') ?? false;
        if (!alreadyMarked) {
          await _markSlotRemainingAsMissed(slotKey);
          await prefs.setBool('slot_missed_${slotKey}_$dayKey', true);
        }
      }
    }
  }

  DateTime _getSlotEndDateTime(String slotKey, DateTime date) {
    if (slotKey.startsWith('custom')) {
      final alarmTime = _getCustomSlotAlarmTime(slotKey, date);
      return alarmTime.add(const Duration(hours: 1));
    }

    final endStr = _slotPrefs['${slotKey}_end'] ?? _defaultSlotEnd(slotKey);
    final parts = endStr.split(':');
    var end = DateTime(
      date.year,
      date.month,
      date.day,
      int.tryParse(parts[0]) ?? 22,
      parts.length > 1 ? int.tryParse(parts[1]) ?? 30 : 30,
    );

    if (slotKey == 'night') {
      final startStr = _slotPrefs['night_start'] ?? '21:00';
      final startParts = startStr.split(':');
      final startHour = int.tryParse(startParts[0]) ?? 21;
      if (end.hour < startHour) {
        end = end.add(const Duration(days: 1));
      }
    }
    return end;
  }

  DateTime _getCustomSlotAlarmTime(String slotKey, DateTime date) {
    final parts = slotKey.split('_');
    if (parts.length >= 3) {
      final medId = parts.sublist(1, parts.length - 1).join('_');
      final idx = int.tryParse(parts.last) ?? 0;
      for (final med in _allMeds) {
        if (med.id == medId && idx < med.customTimes.length) {
          return _parseMedicineTimeForDate(med.customTimes[idx], date) ??
              DateTime(date.year, date.month, date.day, 8);
        }
      }
    }
    return DateTime(date.year, date.month, date.day, 8);
  }

  Future<void> _markSlotRemainingAsMissed(String slotKey) async {
    final userId = _supabase.auth.currentUser?.id;
    if (userId == null) return;

    final remaining = _getRemainingSlotItems(slotKey, DateTime.now());
    if (remaining.isEmpty) return;

    for (final item in remaining) {
      final med = item['medicine'] as Medicine;
      final slot = item['slot'] as int;
      final slotId = _slotKey(med.id ?? '', slot);
      try {
        await _supabase.from('medicine_logs').upsert({
          'user_id': userId,
          'medication_id': med.id,
          'medicine_name': med.name,
          'dosage': med.getCurrentDosage(DateTime.now()),
          'status': 'missed',
          'alarm_slot': slot,
          'scheduled_time': (item['dateTime'] as DateTime).toIso8601String(),
          'created_at': DateTime.now().toIso8601String(),
        }, onConflict: 'medication_id,alarm_slot,scheduled_time', ignoreDuplicates: true);
      } catch (e) {
        // Duplicate log already exists — safe to ignore
        debugPrint('_markSlotRemainingAsMissed: skipping duplicate for ${med.name}: $e');
      }
      _skippedSlotIds.add(slotId);
    }

    final names = remaining.map((m) => (m['medicine'] as Medicine).name).toList();
    await NotificationService().sendSlotMissedAlert(slotKey, names);
    await _alarmService.cancelSlotAlarms(slotKey);
  }

  List<Map<String, dynamic>> _getRemainingSlotItems(String slotKey, DateTime date) {
    final items = <Map<String, dynamic>>[];

    for (final med in _todaysMeds) {
      if (!med.isActive || med.isPaused || !med.isActiveOnDate(date)) continue;

      if (slotKey.startsWith('custom')) {
        final parts = slotKey.split('_');
        if (parts.length < 3) continue;
        final medId = parts.sublist(1, parts.length - 1).join('_');
        final idx = int.tryParse(parts.last);
        if (med.id != medId || idx == null || idx >= med.customTimes.length) continue;
        final slot = 500 + idx;
        final slotId = _slotKey(med.id ?? '', slot);
        if (_takenSlotIdsToday.contains(slotId) || _skippedSlotIds.contains(slotId)) continue;
        items.add({
          'medicine': med,
          'slot': slot,
          'slotKey': slotKey,
          'slotName': 'Custom',
          'dateTime': _parseMedicineTimeForDate(med.customTimes[idx], date) ?? date,
        });
      } else if (med.slotTypes.contains(slotKey)) {
        final slot = _slotIndex(slotKey);
        final slotId = _slotKey(med.id ?? '', slot);
        if (_takenSlotIdsToday.contains(slotId) || _skippedSlotIds.contains(slotId)) continue;
        items.add({
          'medicine': med,
          'slot': slot,
          'slotKey': slotKey,
          'slotName': _slotNameLabel(slotKey),
          'dateTime': _slotStartToday(slotKey),
        });
      }
    }

    return items;
  }

  Future<void> _checkSlotSetupPrompt() async {
    final prefs = await SharedPreferences.getInstance();
    final alreadyShown = prefs.getBool('slot_setup_shown') ?? false;
    if (alreadyShown) return;

    // Check if user already has slot preferences saved
    final result = await Supabase.instance.client
        .from('user_slot_preferences')
        .select('user_id')
        .eq('user_id', Supabase.instance.client.auth.currentUser?.id ?? '')
        .maybeSingle();

    if (result != null) {
      // Already has preferences — mark as shown and skip
      await prefs.setBool('slot_setup_shown', true);
      return;
    }

    if (!mounted) return;

    // Show one-time bottom sheet
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40, height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            const Icon(LucideIcons.clock, size: 48, color: Color(0xFF10B981)),
            const SizedBox(height: 16),
            const Text(
              'Set your medicine schedule times',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              'Get accurate reminders by setting your preferred time ranges for morning, afternoon, evening, and night slots.',
              style: TextStyle(fontSize: 14, color: Colors.grey[600], height: 1.4),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: () async {
                  await prefs.setBool('slot_setup_shown', true);
                  if (ctx.mounted) Navigator.pop(ctx);
                  if (mounted) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const SettingsScreen()),
                    );
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF10B981),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: const Text('Set Now', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 12),
            TextButton(
              onPressed: () async {
                await prefs.setBool('slot_setup_shown', true);
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: Text('Skip for now', style: TextStyle(color: Colors.grey[500], fontSize: 15)),
            ),
          ],
        ),
      ),
    );
  }

  /// 6B — Check if any slot is starting now, send WhatsApp reminder to family admins.
  /// Uses SharedPreferences to avoid sending duplicate reminders within the same slot window.
  Future<void> _checkSlotWhatsAppReminders() async {
    try {
      final now = DateTime.now();
      final todayStr = '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
      final currentMinutes = now.hour * 60 + now.minute;

      // Load slot preferences
      final slotPrefs = await SlotPreferencesService().getPreferences();

      final slotNames = {
        'morning': 'Morning',
        'afternoon': 'Afternoon',
        'evening': 'Evening',
        'night': 'Night',
      };

      final prefs = await SharedPreferences.getInstance();

      for (final entry in slotNames.entries) {
        final slot = entry.key;
        final slotLabel = entry.value;
        final startStr = slotPrefs['${slot}_start'];
        if (startStr == null) continue;

        final parts = startStr.split(':');
        if (parts.length < 2) continue;
        final slotStartMinutes = (int.tryParse(parts[0]) ?? 0) * 60 + (int.tryParse(parts[1]) ?? 0);

        // Check if current time is within 2 minutes of slot start
        final diff = currentMinutes - slotStartMinutes;
        if (diff < 0 || diff > 2) continue;

        // Check if we already sent for this slot today
        final sentKey = 'wa_slot_sent_${todayStr}_$slot';
        if (prefs.getBool(sentKey) == true) continue;

        // Find today's active medications in this slot
        final userId = _supabase.auth.currentUser?.id;
        if (userId == null) continue;

        final response = await _supabase
            .from('medications')
            .select('name, slot_types, is_paused')
            .eq('user_id', userId)
            .eq('is_active', true);

        final medsInSlot = (response as List).where((m) {
          final slots = List<String>.from(m['slot_types'] ?? []);
          final isPaused = m['is_paused'] == true;
          return slots.contains(slot) && !isPaused;
        }).toList();

        if (medsInSlot.isEmpty) continue;

        // Get patient name
        final profile = await _supabase
            .from('profiles')
            .select('full_name')
            .eq('id', userId)
            .maybeSingle();
        final patientName = profile?['full_name'] ?? 'Patient';

        // Send WhatsApp for each medicine in this slot
        for (final med in medsInSlot) {
          final slotStart = DateTime(now.year, now.month, now.day,
              int.tryParse(parts[0]) ?? 0, int.tryParse(parts[1]) ?? 0);
          await NotificationService().sendSlotReminderAlert(
            patientName: patientName,
            medicineName: med['name'] ?? 'Medicine',
            slotName: slotLabel,
            slotStartTime: slotStart,
          );
        }

        // Mark as sent
        await prefs.setBool(sentKey, true);
        debugPrint('WhatsApp slot reminder sent for $slotLabel (${medsInSlot.length} meds)');
      }
    } catch (e) {
      debugPrint('WhatsApp slot reminder check error: $e');
    }
  }

  @override
  void dispose() {
    _minuteTimer?.cancel();
    _medsSubscription?.cancel();
    medicineUpdatedNotifier.removeListener(_onMedicineUpdated);
    activeSlotAlarmNotifier.removeListener(_onSlotAlarmReceived);
    _scrollController.dispose();
    super.dispose();
  }

  void _setupMedsSubscription() {
    final userId = _supabase.auth.currentUser?.id;
    if (userId == null) return;

    _medsSubscription = _supabase
        .from('medications')
        .stream(primaryKey: ['id'])
        .eq('user_id', userId)
        .listen(
          (_) => _initDashboard(),
          onError: (e) => debugPrint('Meds stream error: $e'),
        );
  }

  String _slotKey(String medId, int slot) => '${medId}_$slot';

  List<Map<String, dynamic>> _getUpcomingMedsInWindow() {
    List<Map<String, dynamic>> upcoming = [];
    final now = DateTime.now();

    for (var med in _todaysMeds) {
      final times = [med.time1, med.time2, med.time3];
      for (int index = 0; index < times.length; index++) {
        final timeStr = times[index];
        final slot = index + 1;
        if (timeStr != null && timeStr.isNotEmpty) {
          try {
          final parsedTime = _parseMedicineTimeForDate(timeStr.trim(), now);
            if (parsedTime == null) continue;
            final scheduledDateTime = parsedTime;

            final difference = scheduledDateTime.difference(now).inMinutes;
            final slotKey = _slotKey(med.id ?? '', slot);

            if (difference >= -15 &&
                difference <= 30 &&
                !_takenSlotIdsToday.contains(slotKey) &&
                !_skippedSlotIds.contains(slotKey)) {
              upcoming.add({
                'medicine': med,
                'slot': slot,
                'time': timeStr,
                'dateTime': scheduledDateTime,
              });
            }
          } catch (e) {
            debugPrint('Time parse error: $e');
          }
        }
      }
    }
    upcoming.sort(
      (a, b) => (a['dateTime'] as DateTime).compareTo(b['dateTime'] as DateTime),
    );
    return upcoming;
  }

  /// Returns the slot start DateTime for today
  DateTime _slotStartToday(String slot) {
    final now = DateTime.now();
    if (slot == 'custom') {
      final startStr = _slotPrefs['custom_start'] ?? '08:00';
      final parts = startStr.split(':');
      return DateTime(now.year, now.month, now.day, int.tryParse(parts[0]) ?? 8, int.tryParse(parts.length > 1 ? parts[1] : '0') ?? 0);
    }
    final startStr = _slotPrefs['${slot}_start'] ?? _defaultSlotStart(slot);
    final parts = startStr.split(':');
    return DateTime(now.year, now.month, now.day, int.tryParse(parts[0]) ?? 8, int.tryParse(parts.length > 1 ? parts[1] : '0') ?? 0);
  }

  /// Returns the slot end DateTime for today
  DateTime _slotEndToday(String slot) {
    final now = DateTime.now();
    if (slot == 'custom') {
      final endStr = _slotPrefs['custom_end'] ?? '09:00';
      final parts = endStr.split(':');
      return DateTime(now.year, now.month, now.day, int.tryParse(parts[0]) ?? 9, int.tryParse(parts.length > 1 ? parts[1] : '0') ?? 0);
    }
    final endStr = _slotPrefs['${slot}_end'] ?? _defaultSlotEnd(slot);
    final parts = endStr.split(':');
    return DateTime(now.year, now.month, now.day, int.tryParse(parts[0]) ?? 9, int.tryParse(parts.length > 1 ? parts[1] : '0') ?? 0);
  }

  static String _defaultSlotStart(String slot) {
    switch (slot) {
      case 'morning': return '08:00';
      case 'afternoon': return '12:00';
      case 'evening': return '16:00';
      case 'night': return '21:00';
      default: return '08:00';
    }
  }

  static String _defaultSlotEnd(String slot) {
    switch (slot) {
      case 'morning': return '09:30';
      case 'afternoon': return '14:00';
      case 'evening': return '18:00';
      case 'night': return '22:30';
      default: return '09:30';
    }
  }

  static int _slotIndex(String slot) {
    switch (slot) {
      case 'morning': return 1;
      case 'afternoon': return 2;
      case 'evening': return 3;
      case 'night': return 4;
      case 'custom': return 5;
      default: return 0;
    }
  }

  static String _slotNameLabel(String slot) {
    switch (slot) {
      case 'morning': return 'Morning';
      case 'afternoon': return 'Afternoon';
      case 'evening': return 'Evening';
      case 'night': return 'Night';
      case 'custom': return 'Custom';
      default: return slot;
    }
  }

  List<Map<String, dynamic>> _getDueSoonMeds() {
    final now = DateTime.now();
    final dueSoon = <Map<String, dynamic>>[];

    for (final med in _todaysMeds) {
      if (!med.isActive || med.isPaused) continue;
      if (!med.isActiveOnDate(now)) continue;

      for (final slot in med.slotTypes) {
        if (slot == 'custom') {
          for (int i = 0; i < med.customTimes.length; i++) {
            final timeStr = med.customTimes[i];
            DateTime? customAlarmTime;

            try {
              DateTime parsed;
              if (timeStr.contains('AM') || timeStr.contains('PM')) {
                parsed = DateFormat('hh:mm a').parseStrict(timeStr.trim());
              } else {
                parsed = DateFormat('HH:mm').parseStrict(timeStr.trim());
              }
              customAlarmTime = DateTime(
                now.year,
                now.month,
                now.day,
                parsed.hour,
                parsed.minute,
              );
            } catch (_) {
              continue;
            }

            final diff = customAlarmTime.difference(now).inMinutes;
            // C8: Extended Due Soon window for custom times from +15 min to +60 min.
            // Previously a card disappeared after 16 min even if the alarm was still pending auto-stop.
            // +60 min is consistent with _getSlotEndDateTime() which adds +1 hour for custom times.
            if (diff >= -30 && diff <= 60) {
              final slotId = _slotKey(med.id ?? '', 500 + i);
              final slotKey = 'custom_${med.id}_$i';
              if (!_takenSlotIdsToday.contains(slotId) &&
                  !_skippedSlotIds.contains(slotId)) {
                dueSoon.add({
                  'medicine': med,
                  'slot': 500 + i,
                  'slotKey': slotKey,
                  'customTimeStr': timeStr,
                  'slotName': 'Custom',
                  'dateTime': customAlarmTime,
                });
              }
            }
          }
        } else {
          final slotStart = _slotStartToday(slot);
          final slotEnd = _slotEndToday(slot);

          // Medicine is due if current time is within the slot range
          if (now.isAfter(slotStart) && now.isBefore(slotEnd)) {
            final slotIdx = _slotIndex(slot);
            final slotId = _slotKey(med.id ?? '', slotIdx);
            if (!_takenSlotIdsToday.contains(slotId) &&
                !_skippedSlotIds.contains(slotId)) {
              dueSoon.add({
                'medicine': med,
                'slot': slotIdx,
                'slotKey': slot,
                'slotName': _slotNameLabel(slot),
                'dateTime': slotStart,
              });
            }
          }
        }
      }
    }

    dueSoon.sort(
      (a, b) => (a['dateTime'] as DateTime).compareTo(b['dateTime'] as DateTime),
    );
    return dueSoon;
  }

  List<Map<String, dynamic>> _getDueSoonMixed() {
    final List<Map<String, dynamic>> mixed = [];
    
    // 1. Add Meds (due soon)
    final meds = _getDueSoonMeds();
    for (final m in meds) {
      mixed.add({
        'type': 'med',
        'time': m['dateTime'] as DateTime,
        'data': m,
      });
    }

    // 2. Add Today's Appointments (upcoming)
    final now = DateTime.now();
    for (final a in _todaysAppointments) {
      final timeStr = a['appointment_date'].toString();
      final time = DateTime.tryParse(timeStr)?.toLocal() ?? now;
      if (time.isAfter(now.subtract(const Duration(hours: 1)))) {
        mixed.add({
          'type': 'appointment',
          'time': time,
          'data': a,
        });
      }
    }

    // 3. Add Today's Tasks
    for (final t in _todaysTasks) {
      final timeStr = t['due_at'].toString();
      final time = DateTime.tryParse(timeStr)?.toLocal() ?? now;
      if (time.isAfter(now.subtract(const Duration(hours: 1)))) {
        mixed.add({
          'type': 'task',
          'time': time,
          'data': t,
        });
      }
    }

    mixed.sort((a, b) => (a['time'] as DateTime).compareTo(b['time'] as DateTime));
    return mixed;
  }

  // _removeDueSoonItem removed as we use horizontal ListView without AnimatedList

  /// PHASE 2: Undo "Mark as Taken" within 10 seconds.
  /// Restores qty, deletes the log row created by _onEarlyTake.
  Future<void> _undoEarlyTake({
    required String medId,
    required String slotId,
    required int restoredQty,
    required String logCreatedAt,
    required Map<String, dynamic> originalItem,
  }) async {
    try {
      // Restore qty in DB
      await _supabase
          .from('medications')
          .update({'qty': restoredQty, 'is_active': true})
          .eq('id', medId);

      // Delete the log row (match on exact created_at timestamp)
      await _supabase
          .from('medicine_logs')
          .delete()
          .eq('medication_id', medId)
          .eq('created_at', logCreatedAt);

      if (mounted) {
        // Remove from taken set — puts card back in Due Soon
        setState(() {
          _takenSlotIdsToday.remove(slotId);
          _cachedDueSoon = _getDueSoonMeds();
        });
        // Animate item back in
        _cachedDueSoon = _getDueSoonMeds();
        AppSnackBar.showSuccess(context, 'Undo done — dose restored ✅');
      }
    } catch (e) {
      debugPrint('Undo error: $e');
      if (mounted) AppSnackBar.showError(context, 'Undo failed: $e');
    }
  }

  Future<void> _onEarlyTake(Map<String, dynamic> med) async {

    try {
      final medicine = med['medicine'] as Medicine;
      final medId = medicine.id;
      final int slot = med['slot'] as int;
      final slotKey = med['slotKey'] as String?;
      // C10: Normalize scheduledTime to minute precision to prevent duplicate logs.
      // The alarm engine saves scheduled_time at exact alarm fire time (with seconds/ms),
      // while Due Soon calculates it fresh from the time string (always :00 seconds).
      // A mismatch causes two separate DB rows for the same dose.
      final rawScheduledTime = med['dateTime'] as DateTime;
      final scheduledTime = DateTime(
        rawScheduledTime.year,
        rawScheduledTime.month,
        rawScheduledTime.day,
        rawScheduledTime.hour,
        rawScheduledTime.minute,
      );
      if (medId == null) throw Exception('Medicine ID is missing');

      final alarmId = slot == 1
          ? medicine.alarmId1
          : slot == 2 ? medicine.alarmId2 : medicine.alarmId3;

      if (alarmId != null) await _alarmService.cancelAlarm(alarmId);

      // Fresh qty fetch
      int currentQty = medicine.qty; // Fallback to local
      try {
        final latest = await _supabase
            .from('medications').select('qty').eq('id', medId).maybeSingle();
        if (latest != null) {
          currentQty = int.tryParse(latest['qty'].toString()) ?? currentQty;
        }
      } catch (e) {
        if (!OfflineSyncService.isOfflineError(e)) {
           if (mounted) {
             _takenSlotIdsToday.add(_slotKey(medId, slot));
             AppSnackBar.showSuccess(context, 'Medicine marked as taken!');
           }
           return;
        }
      }
      
      final newQty = (currentQty - 1).clamp(0, 99999);

      final userId = _supabase.auth.currentUser?.id;
      final now = DateTime.now();
      final logCreatedAt = now.toIso8601String();

      try {
        await _supabase
            .from('medications')
            .update({'qty': newQty, if (newQty == 0) 'is_active': false})
            .eq('id', medId);

        await _supabase.from('medicine_logs').insert({
          'user_id': userId,
          'medication_id': medId,
          'medicine_name': medicine.name,
          'dosage': medicine.getCurrentDosage(DateTime.now()),
          'status': 'taken',
          'alarm_slot': slot,
          'scheduled_time': scheduledTime.toIso8601String(),
          'created_at': logCreatedAt,
          'administered_by': userId,
        });
      } catch (e) {
        if (OfflineSyncService.isOfflineError(e)) {
          await OfflineSyncService.instance.enqueueAction(
            type: 'medications_update_qty',
            payload: {'id': medId, 'qty': newQty, 'is_active': newQty == 0 ? false : null},
          );
          await OfflineSyncService.instance.enqueueAction(
            type: 'medicine_logs_insert',
            payload: {
              'user_id': userId,
              'medication_id': medId,
              'medicine_name': medicine.name,
              'dosage': medicine.getCurrentDosage(DateTime.now()),
              'status': 'taken',
              'alarm_slot': slot,
              'scheduled_time': scheduledTime.toIso8601String(),
              'created_at': logCreatedAt,
              'administered_by': userId,
            },
          );
        } else {
          rethrow;
        }
      }

      try {
        await ActivityService.log(
          actionType: 'MEDICINE_TAKEN',
          description: 'Took ${medicine.name}',
        );
      } catch (e) { debugPrint('Feed log error: $e'); }

      if (mounted) {
        final slotId = _slotKey(medId, slot);
        setState(() {
          _takenSlotIdsToday.add(slotId);
          _skippedSlotIds.remove(slotId);
        });
        if (slotKey != null) await _checkAndScheduleRetry(slotKey);
        
        if (!mounted) return;
        _initDashboard();

        // PHASE 3 Missing #10: If medicine is now out of stock, prompt refill reminder
        if (newQty == 0 && mounted) {
          showDialog(
            context: context,
            builder: (ctx) => AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              title: const Text('Medicine Finished 💊'),
              content: Text('${medicine.name} is now out of stock.\nWould you like a refill reminder tomorrow morning?'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('No Thanks'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    Navigator.pop(ctx);
                    // Use AlarmService fallback notification (no showScheduledNotification method exists)
                    await AlarmService.instance.notificationsPlugin.show(
                      medicine.id.hashCode & 0x7FFFFFFF,
                      '💊 Refill Reminder',
                      'Time to refill ${medicine.name}. You ran out yesterday.',
                      null,
                    );
                    if (mounted) AppSnackBar.showSuccess(context, '⏰ Refill reminder set for tomorrow morning!');
                  },
                  child: const Text('Set Reminder'),
                ),
              ],
            ),
          );
        } else {
          // PHASE 2: 10-second Undo snackbar
          ScaffoldMessenger.of(context).clearSnackBars();
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('✅ ${medicine.name} marked as taken'),
              duration: const Duration(seconds: 10),
              backgroundColor: const Color(0xFF16A34A),
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              action: SnackBarAction(
                label: 'UNDO',
                textColor: Colors.white,
                onPressed: () => _undoEarlyTake(
                  medId: medId,
                  slotId: slotId,
                  restoredQty: currentQty, // Original qty before decrement
                  logCreatedAt: logCreatedAt,
                  originalItem: med,
                ),
              ),
            ),
          );
        }
      }
    } catch (e) {
      debugPrint('Error in _onEarlyTake: $e');
      if (mounted) AppSnackBar.showError(context, 'Error: $e');
    }
  }

  Future<void> _onSkipWindow(Map<String, dynamic> med) async {
    final medicine = med['medicine'] as Medicine;
    final slot = med['slot'] as int;
    final slotKey = med['slotKey'] as String?;
    final slotId = _slotKey(medicine.id ?? '', slot);
    final scheduledTime = med['dateTime'] as DateTime;

    // 1. UI se immediately hatao
    setState(() {
      _skippedSlotIds.add(slotId);
    });

    // 2. Alarm cancel karo (warna bajta rahega)
    try {
      final alarmId = slot == 1
          ? medicine.alarmId1
          : slot == 2
              ? medicine.alarmId2
              : medicine.alarmId3;
      if (alarmId != null) {
        await _alarmService.cancelAlarm(alarmId);
      }
    } catch (e) {
      debugPrint('Cancel alarm error: $e');
    }

    // DB mein save karo — capture logCreatedAt for undo
    String? skipLogCreatedAt;
    try {
      final userId = _supabase.auth.currentUser?.id;
      if (userId != null && medicine.id != null) {
        skipLogCreatedAt = DateTime.now().toIso8601String();
        try {
          await _supabase.from('medicine_logs').insert({
            'user_id': userId,
            'medication_id': medicine.id,
            'medicine_name': medicine.name,
            'dosage': medicine.getCurrentDosage(DateTime.now()),
            'status': 'skipped',
            'alarm_slot': slot,
            'scheduled_time': scheduledTime.toIso8601String(),
            'created_at': skipLogCreatedAt,
            'administered_by': userId,
          });
        } catch (e) {
          if (OfflineSyncService.isOfflineError(e)) {
            await OfflineSyncService.instance.enqueueAction(
              type: 'medicine_logs_insert',
              payload: {
                'user_id': userId,
                'medication_id': medicine.id,
                'medicine_name': medicine.name,
                'dosage': medicine.getCurrentDosage(DateTime.now()),
                'status': 'skipped',
                'alarm_slot': slot,
                'scheduled_time': scheduledTime.toIso8601String(),
                'created_at': skipLogCreatedAt,
                'administered_by': userId,
              },
            );
          } else {
            rethrow;
          }
        }
      }
    } catch (e) {
      debugPrint('Skip log error: $e');
    }

    if (slotKey != null) await _checkAndScheduleRetry(slotKey);
    
    if (!mounted) return;

    if (mounted) {
      // PHASE 2: 10-second Undo snackbar for skip
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('⏭ ${medicine.name} dose skipped'),
          duration: const Duration(seconds: 10),
          backgroundColor: const Color(0xFF475569),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          action: skipLogCreatedAt != null && medicine.id != null
              ? SnackBarAction(
                  label: 'UNDO',
                  textColor: Colors.white,
                  onPressed: () async {
                    try {
                      // Delete the skip log
                      await _supabase
                          .from('medicine_logs')
                          .delete()
                          .eq('medication_id', medicine.id!)
                          .eq('created_at', skipLogCreatedAt!);
                      if (mounted) {
                        setState(() {
                          _skippedSlotIds.remove(slotId);
                          _cachedDueSoon = _getDueSoonMeds();
                        });
                        AppSnackBar.showSuccess(context, 'Skip undone — dose restored ✅');
                      }
                    } catch (e) {
                      if (mounted) AppSnackBar.showError(context, 'Undo failed: $e');
                    }
                  },
                )
              : null,
        ),
      );
    }
  }

  Future<void> _initDashboard() async {
    if (_isRefreshingDashboard) return;
    _isRefreshingDashboard = true;
    try {
      final userId = _supabase.auth.currentUser?.id;
      if (userId == null) return;

      // PHASE 2: Attempt offline sync
      await OfflineSyncService.instance.attemptSync();

      // Load slot preferences for Due Soon panel
      final slotPrefs = await SlotPreferencesService().getPreferences();

      // 1. Fetch ALL medications (no is_active filter — filter locally like meds_screen)
      final response = await _supabase
          .from('medications')
          .select()
          .eq('user_id', userId);

      debugPrint("Dashboard: Fetched ${response.length} active meds from DB.");

      final now = DateTime.now();
      final today = DateTime(now.year, now.month, now.day);

      int tempTotal = 0;
      final allMeds = <Medicine>[];
      List<Medicine> todaysMeds = [];

      // 2. Filter locally with foolproof inclusive date check
      for (var item in response) {
        final med = Medicine.fromJson(item);
        allMeds.add(med);
        final start = DateTime(med.startDate.year, med.startDate.month, med.startDate.day);
        DateTime end = DateTime(med.endDate.year, med.endDate.month, med.endDate.day);
        final parsedEndDate = DateTime.tryParse(item['end_date']?.toString() ?? '');
        if (parsedEndDate != null) {
          end = DateTime(parsedEndDate.year, parsedEndDate.month, parsedEndDate.day);
        }

        // compareTo logic: 0 means same day, >0 means today is after start, <0 means today is before end
        if (today.compareTo(start) >= 0 && today.compareTo(end) <= 0) {
          todaysMeds.add(med);
          tempTotal += med.frequency; // Total doses for today
        }
      }

      debugPrint("Dashboard: ${todaysMeds.length} meds scheduled for exactly today. Total doses: $tempTotal");

      // 8A — Low stock alert check (fire-and-forget, don't block dashboard)
      _checkLowStockAlerts(todaysMeds);

      // 3. Fetch taken logs for today safely
      final startOfDay = DateTime(now.year, now.month, now.day).toUtc().toIso8601String();
      final endOfDay = DateTime(now.year, now.month, now.day, 23, 59, 59).toUtc().toIso8601String();
      
      final logsResponse = await _supabase
          .from('medicine_logs')
          .select()
          .eq('user_id', userId)
          .inFilter('status', ['taken', 'skipped', 'missed'])
          .gte('created_at', startOfDay)
          .lte('created_at', endOfDay);

      final allLogs = List<Map<String, dynamic>>.from(logsResponse as List);
      // Taken + skipped dono hide karo Today's Medicines se
      final hiddenSlotIds = allLogs
          .where((log) => log['medication_id'] != null && log['alarm_slot'] != null)
          .map((log) => _slotKey(log['medication_id'].toString(), int.tryParse(log['alarm_slot'].toString()) ?? 1))
          .toSet();
      // Adherence ke liye sirf taken count karo
      int tempTaken = allLogs.where((log) => log['status'] == 'taken').length;

      // 9A — Schedule daily summary notification at 10 PM
      _alarmService.scheduleDailySummary(taken: tempTaken, total: tempTotal);

      // Fetch missed medicines (last 7 days)
      final sevenDaysAgo = DateTime.now()
          .subtract(const Duration(days: 7))
          .toIso8601String();
      final missedResponse = await _supabase
          .from('medicine_logs')
          .select('medicine_name, scheduled_time, alarm_slot')
          .eq('user_id', userId)
          .eq('status', 'missed')
          .gte('scheduled_time', sevenDaysAgo)
          .order('scheduled_time', ascending: false)
          .limit(10);
      final missedLogs = List<Map<String, dynamic>>.from(missedResponse as List);

      // Fetch next upcoming appointment
      Map<String, dynamic>? nextAppointment;
      try {
        nextAppointment = await _supabase
            .from('appointments')
            .select('doctor_name, appointment_date, notes')
            .eq('user_id', userId)
            .gte('appointment_date', DateTime.now().toIso8601String())
            .order('appointment_date', ascending: true)
            .limit(1)
            .maybeSingle();

        // Also fetch ALL of today's appointments for Due Soon Strip
        final startOfDay = DateTime(now.year, now.month, now.day).toIso8601String();
        final endOfDay = DateTime(now.year, now.month, now.day, 23, 59, 59).toIso8601String();
        
        final apptResponse = await _supabase
            .from('appointments')
            .select()
            .eq('user_id', userId)
            .gte('appointment_date', startOfDay)
            .lte('appointment_date', endOfDay)
            .order('appointment_date', ascending: true);
        if (mounted) _todaysAppointments = List<Map<String, dynamic>>.from(apptResponse as List);
      } catch (e) {
        debugPrint('Fetch next appointment error: $e');
      }

      // 4. Find Next Medication (Closest upcoming time not taken)
      Medicine? nextMedication;
      DateTime? closestTime;
      String? nextSlotLabel;

      for (var med in todaysMeds) {
        final activeTimes = med.activeTimes;
        for (int i = 0; i < activeTimes.length; i++) {
          final timeStr = activeTimes[i];
          final slot = i + 1;

          try {
            final scheduledTime = _parseMedicineTimeForDate(timeStr, today);
            if (scheduledTime == null) continue;

            // Check if already taken today
            bool alreadyTaken = allLogs.any((log) =>
              log['medication_id'] == med.id && log['alarm_slot'] == slot
            );

            if (!alreadyTaken && scheduledTime.isAfter(now)) {
              if (closestTime == null || scheduledTime.isBefore(closestTime)) {
                closestTime = scheduledTime;
                nextMedication = med;
                nextSlotLabel = timeStr;
              }
            }
          } catch (e) {
            debugPrint("Error parsing time for next med: $e");
          }
        }
      }

      // Fetch Latest Vital
      final vitalsData = await _supabase.from('vitals')
          .select('*')
          .eq('user_id', userId)
          .order('measured_at', ascending: false)
          .limit(1)
          .maybeSingle();

      // Fetch Family Members
      final familyData = await _supabase.from('family_members')
          .select('group_id')
          .eq('user_id', userId)
          .maybeSingle();
      
      int familyMembers = 0;
      if (familyData != null) {
        final members = await _supabase.from('family_members')
            .select('id')
            .eq('group_id', familyData['group_id']);
        familyMembers = (members as List).length;

        // Fetch Today's Family Tasks for Due Soon Strip
        try {
          final startOfDay = DateTime(now.year, now.month, now.day).toIso8601String();
          final endOfDay = DateTime(now.year, now.month, now.day, 23, 59, 59).toIso8601String();
          
          final tasksResponse = await _supabase
              .from('family_tasks')
              .select()
              .eq('group_id', familyData['group_id'])
              .inFilter('status', ['pending', 'in_progress'])
              .gte('due_at', startOfDay)
              .lte('due_at', endOfDay)
              .order('due_at', ascending: true);
          if (mounted) _todaysTasks = List<Map<String, dynamic>>.from(tasksResponse as List);
        } catch (e) {}
      }

      // Calculate streak (single optimized query)
      final streak = await _calculateStreak(userId);

      // Fetch Profile Name
      final profileData = await _supabase.from('profiles').select('full_name').eq('id', userId).maybeSingle();
      if (profileData != null && mounted) setState(() => _fullName = profileData['full_name']);

      // Check image existence before setState
      _existingImagePaths.clear();
      final List<Future<void>> imageChecks = [];
      for (final m in todaysMeds) {
        if (m.imagePath != null && m.imagePath!.isNotEmpty) {
          imageChecks.add(File(m.imagePath!).exists().then((exists) {
            if (exists) _existingImagePaths.add(m.imagePath!);
          }));
        }
      }
      await Future.wait(imageChecks);

      if (mounted) {
        setState(() {
          _todaysMeds = todaysMeds;
          _allMeds = allMeds;
          _slotPrefs = slotPrefs;
          _takenSlotIdsToday
            ..clear()
            ..addAll(hiddenSlotIds);
          // Sync skipped from DB so cross-clicked cards survive restart
          _skippedSlotIds
            ..clear()
            ..addAll(allLogs
                .where((log) =>
                    log['status'] == 'skipped' &&
                    log['medication_id'] != null &&
                    log['alarm_slot'] != null)
                .map((log) => _slotKey(
                    log['medication_id'].toString(), int.tryParse(log['alarm_slot'].toString()) ?? 1)));
          _latestVital = vitalsData;
          _totalMedsToday = tempTotal;
          _takenMedsToday = tempTaken;
          _familyCount = familyMembers;
          _streakDays = streak;
          _checkStreakCelebration(streak);
          _isLoading = false;
          
          _nextMedData = nextMedication != null ? {
            'name': nextMedication.name,
            'medicationId': nextMedication.id,
            'dosage': nextMedication.getCurrentDosage(closestTime ?? DateTime.now()),
            'image_path': nextMedication.imagePath,
          } : null;
          _nextMedTimeLabel = nextSlotLabel;
          _missedLogs = missedLogs;
          _nextAppointment = nextAppointment;
          _cachedDueSoon = _getDueSoonMeds();
        });
      }
    } catch (e) {
      debugPrint("Dashboard Fetch Error: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Dashboard Error: ${e.toString()}')),
        );
        setState(() => _isLoading = false);
      }
    } finally {
      _isRefreshingDashboard = false;
      // Failed alarm warnings: getFailedAlarms() was removed from AlarmService.
      // Warnings are now surfaced only when scheduleAlarm() returns false (C11 fix).
    }
  }

  /// 8A — Check low stock and send alerts (fire-and-forget from _initDashboard)
  Future<void> _checkLowStockAlerts(List<Medicine> meds) async {
    try {
      for (final med in meds) {
        if (med.id == null) continue;

        if (med.qty <= 5 && !med.lowStockAlerted && !med.isPaused) {
          // Local notification
          await NotificationService().showLocalNotification(
            title: 'Low Stock Alert',
            body: '${med.name} — sirf ${med.qty} doses bachi hain. Refill karo!',
          );
          // WhatsApp to family admin
          await NotificationService().sendLowStockAlert(med.name, med.qty);
          // Mark as alerted in DB
          await _supabase
              .from('medications')
              .update({'low_stock_alerted': true})
              .eq('id', med.id!);
          debugPrint('Low stock alert sent for ${med.name} (${med.qty} left)');
        }

        // Reset alert flag when qty is refilled above 5
        if (med.qty > 5 && med.lowStockAlerted) {
          await _supabase
              .from('medications')
              .update({'low_stock_alerted': false})
              .eq('id', med.id!);
          debugPrint('Low stock alert reset for ${med.name} (${med.qty} left)');
        }
      }
    } catch (e) {
      debugPrint('Low stock check error: $e');
    }
  }

  Future<int> _calculateStreak(String userId) async {
    // Fetch last 30 days of ALL logs (not just taken) using scheduled_time
    final thirtyDaysAgo = DateTime.now()
        .subtract(const Duration(days: 30))
        .toUtc()
        .toIso8601String();

    final logs = await _supabase
        .from('medicine_logs')
        .select('scheduled_time, medication_id, status')
        .eq('user_id', userId)
        .gte('scheduled_time', thirtyDaysAgo);

    // Group logs by scheduled date — count taken per medicine per day
    final takenPerDate = <DateTime, Set<String>>{};
    for (final log in (logs as List)) {
      if (log['status'] != 'taken') continue;
      final dt = DateTime.tryParse(log['scheduled_time']?.toString() ?? '');
      if (dt == null) continue;
      final local = dt.toLocal();
      final dateKey = DateTime(local.year, local.month, local.day);
      final medId = log['medication_id']?.toString() ?? '';
      takenPerDate.putIfAbsent(dateKey, () => {}).add(medId);
    }

    // Fetch all medications to compute scheduled medicine count per day
    final medsResponse = await _supabase
        .from('medications')
        .select('id, start_date, end_date, is_paused, is_active, slot_types')
        .eq('user_id', userId);

    final allMeds = (medsResponse as List).map((m) {
      final start = DateTime.tryParse(m['start_date']?.toString() ?? '') ?? DateTime.now();
      final end = DateTime.tryParse(m['end_date']?.toString() ?? '') ?? DateTime.now();
      return {
        'id': m['id']?.toString() ?? '',
        'start': DateTime(start.year, start.month, start.day),
        'end': DateTime(end.year, end.month, end.day),
        'isPaused': m['is_paused'] == true,
        'isActive': m['is_active'] != false,
        'slotCount': (m['slot_types'] as List?)?.length ?? 1,
      };
    }).toList();

    // Count consecutive "perfect" days from today backwards
    int streak = 0;
    final now = DateTime.now();
    for (int i = 0; i < 30; i++) {
      final checkDate = DateTime(now.year, now.month, now.day)
          .subtract(Duration(days: i));

      // Count scheduled medicines for this day
      int scheduledMeds = 0;
      for (final m in allMeds) {
        if (m['isPaused'] == true || m['isActive'] == false) continue;
        final start = m['start'] as DateTime;
        final end = m['end'] as DateTime;
        if (!checkDate.isBefore(start) && !checkDate.isAfter(end)) {
          scheduledMeds++;
        }
      }

      // Skip days with no scheduled medicines
      if (scheduledMeds == 0) {
        if (i == 0) continue;
        break;
      }

      // Perfect day: ALL scheduled medicines have at least one taken log
      final takenMedIds = takenPerDate[checkDate] ?? {};
      final allTaken = takenMedIds.length >= scheduledMeds;

      if (allTaken) {
        streak++;
      } else if (i > 0) {
        break;
      }
    }
    return streak;
  }

  String _getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return "Good Morning";
    if (hour < 17) return "Good Afternoon";
    return "Good Evening";
  }

  @override
  Widget build(BuildContext context) {
    final user = _supabase.auth.currentUser;
    final displayName = _fullName ?? user?.email?.split('@')[0] ?? "User";

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: const Text('FamCare', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF0EA5E9))),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(LucideIcons.inbox, color: Color(0xFF0EA5E9)),
            tooltip: "Inbox",
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const NotificationInboxScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(LucideIcons.activity, color: Color(0xFF0EA5E9)),
            tooltip: "Health Hub",
            onPressed: () => widget.onTabChange(2),
          ),
          IconButton(
            icon: const Icon(LucideIcons.bellRing, color: Color(0xFF0EA5E9)),
            tooltip: "Alarm Setup",
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const AlarmSetupScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(LucideIcons.settings, color: Colors.grey),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const SettingsScreen()),
            ),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _initDashboard,
              child: SingleChildScrollView(
                controller: _scrollController,
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // 1. Welcome Header
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('${_getGreeting()},', style: TextStyle(fontSize: 16, color: Colors.grey[600], letterSpacing: 0.5)),
                        Text('$displayName!', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFF1E293B))),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // 2. Quick Stats Chips
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          _buildStatChip('Meds Today', '$_takenMedsToday/$_totalMedsToday', LucideIcons.pill, Colors.orange),
                          const SizedBox(width: 12),
                          GestureDetector(
                            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AchievementsScreen())),
                            child: _buildStatChip('Streak', '$_streakDays Days', LucideIcons.flame, Colors.red),
                          ),
                          const SizedBox(width: 12),
                          _buildStatChip('Family', '$_familyCount Members', LucideIcons.users, Colors.green),
                        ],
                      ),
                    ),
                    const SizedBox(height: 25),

                    // 3. Quick Actions
                    const Text('Quick Actions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF334155))),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _buildQuickAction(context, 'Log Vital', LucideIcons.activity, const Color(0xFF0EA5E9), () => widget.onTabChange(2)),
                        _buildQuickAction(context, 'Refill', LucideIcons.pill, Colors.orange, () {
                          showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => RefillCenterSheet(medications: _allMeds, onRefillComplete: () => _initDashboard()));
                        }),
                        _buildQuickAction(context, 'Upload Rx', LucideIcons.filePlus, Colors.purple, () {
                          showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => const RecordUploadSheet());
                        }),
                        _buildQuickAction(context, 'Family', LucideIcons.users, Colors.green, () => widget.onTabChange(3)),
                        _buildQuickAction(context, 'Book Appt', LucideIcons.calendarPlus, const Color(0xFFF59E0B), () {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const AppointmentScreen()));
                        }),
                      ],
                    ),
                    const SizedBox(height: 30),

                    // 4. Family Action Needed Badge
                    Consumer(
                      builder: (context, ref, _) {
                        final membership = ref.watch(familyMembershipProvider);
                        if (membership.value == null || membership.value!['group_id'] == null) return const SizedBox.shrink();
                        
                        final alertsAsync = ref.watch(familyAlertsProvider(membership.value!['group_id'] as String));
                        return alertsAsync.when(
                          data: (alerts) {
                            final unacknowledged = alerts.where((a) => a['status'] == 'open').toList();
                            if (unacknowledged.isEmpty) return const SizedBox.shrink();
                            
                            return GestureDetector(
                              onTap: () => widget.onTabChange(3),
                              child: Container(
                                margin: const EdgeInsets.only(bottom: 25),
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(color: Colors.red[50], borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.red[200]!)),
                                child: Row(
                                  children: [
                                    Icon(LucideIcons.alertTriangle, color: Colors.red[600], size: 24),
                                    const SizedBox(width: 16),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text('Family Action Needed', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.red[800])),
                                          Text('${unacknowledged.length} alert(s) require your attention.', style: TextStyle(color: Colors.red[600], fontSize: 14)),
                                        ],
                                      ),
                                    ),
                                    Icon(LucideIcons.chevronRight, color: Colors.red[400]),
                                  ],
                                ),
                              ),
                            );
                          },
                          loading: () => const SizedBox.shrink(),
                          error: (_, __) => const SizedBox.shrink(),
                        );
                      },
                    ),

                    // 5. Failed Alarm Warning
                    if (_failedAlarmWarnings.isNotEmpty) ...[
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(color: const Color(0xFFFEF2F2), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFDC2626).withValues(alpha: 0.3))),
                        child: Row(
                          children: [
                            const Icon(LucideIcons.alertTriangle, color: Color(0xFFDC2626), size: 20),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text('⚠️ Alarm scheduling failed', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFDC2626), fontSize: 13)),
                                  const SizedBox(height: 2),
                                  Text(_failedAlarmWarnings.map((f) => f['name'] ?? 'Unknown').join(', '), style: TextStyle(color: Colors.red[700], fontSize: 12)),
                                  const Text('These reminders may not ring. Please reschedule.', style: TextStyle(color: Color(0xFF7F1D1D), fontSize: 11)),
                                ],
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.close, color: Color(0xFFDC2626), size: 18),
                              onPressed: () { if (mounted) setState(() => _failedAlarmWarnings = []); },
                              tooltip: 'Dismiss', padding: EdgeInsets.zero, constraints: const BoxConstraints(),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                    ],

                    // 6. Low Stock Warning
                    Builder(
                      builder: (context) {
                        final lowStockMeds = _allMeds.where((m) => m.qty <= 5 && !m.isPaused).toList();
                        if (lowStockMeds.isEmpty) return const SizedBox.shrink();
                        
                        final displayMeds = lowStockMeds.take(3).map((m) => '${m.name} (${m.qty})').join(', ');
                        final extraCount = lowStockMeds.length > 3 ? ' +${lowStockMeds.length - 3} more' : '';
                        
                        return Column(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                              decoration: BoxDecoration(color: Colors.orange.shade50, borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.orange.shade400.withValues(alpha: 0.5))),
                              child: Row(
                                children: [
                                  Icon(LucideIcons.alertCircle, color: Colors.orange.shade800, size: 20),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text('Low Stock Alert', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orange.shade900, fontSize: 13)),
                                        const SizedBox(height: 2),
                                        Text('$displayMeds$extraCount', style: TextStyle(color: Colors.orange.shade800, fontSize: 12)),
                                        Text('Please refill these medications soon.', style: TextStyle(color: Colors.orange.shade900, fontSize: 11)),
                                      ],
                                    ),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => RefillCenterSheet(medications: _allMeds, onRefillComplete: () => _initDashboard()));
                                    },
                                    style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 12), minimumSize: Size.zero, tapTargetSize: MaterialTapTargetSize.shrinkWrap),
                                    child: Text('Refill', style: TextStyle(color: Colors.orange.shade900, fontWeight: FontWeight.bold)),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 16),
                          ],
                        );
                      }
                    ),

                    // 7. Due Soon (Today) Strip
                    Builder(
                      builder: (context) {
                        final mixedList = _getDueSoonMixed();
                        if (mixedList.isEmpty) return const SizedBox.shrink();
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Due Soon (Today)', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF334155))),
                            const SizedBox(height: 12),
                            SizedBox(
                              height: 130,
                              child: ListView.builder(
                                scrollDirection: Axis.horizontal,
                                itemCount: mixedList.length,
                                itemBuilder: (context, index) {
                                  return _buildMixedDueSoonCard(mixedList[index]);
                                },
                              ),
                            ),
                            const SizedBox(height: 25),
                          ],
                        );
                      },
                    ),

                    // 8. Today's Progress Card
                    const Text('Today\'s Progress', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF334155))),
                    const SizedBox(height: 12),
                    _buildProgressCard(),
                    const SizedBox(height: 25),
                    
                    // 9. Latest Reading Card
                    const Text('Latest Reading', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF334155))),
                    const SizedBox(height: 12),
                    _buildVitalsSummary(),
                    const SizedBox(height: 25),

                    // 10. Next Appointment Card
                    const Text('Next Appointment', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF334155))),
                    const SizedBox(height: 12),
                    if (_nextAppointment != null) _buildNextAppointmentCard() else _buildEmptyAppointmentCard(),
                    const SizedBox(height: 25),

                    // 11. Missed Medicines (last 7 days - top 3 only)
                    if (_missedLogs.isNotEmpty) ...[
                      const Text('Missed Medicines', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF334155))),
                      const SizedBox(height: 12),
                      Column(
                        children: _missedLogs.take(3).map((log) {
                          final name = log['medicine_name'] ?? 'Medicine';
                          final scheduled = log['scheduled_time'] != null ? DateTime.tryParse(log['scheduled_time'].toString())?.toLocal() : null;
                          final slot = log['alarm_slot'];
                          final dateStr = scheduled != null ? '${scheduled.day}/${scheduled.month} ${scheduled.hour.toString().padLeft(2, '0')}:${scheduled.minute.toString().padLeft(2, '0')}' : '';
                          final slotLabel = slot == 1 ? 'Morning' : slot == 2 ? 'Afternoon' : slot == 3 ? 'Evening' : 'Dose';
                          return Container(
                            margin: const EdgeInsets.only(bottom: 8),
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border(left: BorderSide(color: Colors.red[400]!, width: 4)), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 6, offset: const Offset(0, 2))]),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: Color(0xFF334155))),
                                      const SizedBox(height: 4),
                                      Text('$dateStr  •  $slotLabel', style: TextStyle(fontSize: 12, color: Colors.grey[500])),
                                    ],
                                  ),
                                ),
                                Icon(LucideIcons.xCircle, color: Colors.red[300], size: 18),
                              ],
                            ),
                          );
                        }).toList(),
                      ),
                      if (_missedLogs.length > 3)
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0, bottom: 20.0),
                          child: Center(
                            child: Text('+${_missedLogs.length - 3} more missed', style: TextStyle(color: Colors.grey[500], fontSize: 12, fontStyle: FontStyle.italic)),
                          ),
                        ),
                      const SizedBox(height: 30),
                    ],

                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildTodayMedicineCard(Map<String, dynamic> item) {
    final med = item['medicine'] as Medicine;
    final imagePath = med.imagePath;
    final hasImage = imagePath != null && imagePath.isNotEmpty && _existingImagePaths.contains(imagePath);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.grey[100]!),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: const Color(0xFF0EA5E9).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: hasImage
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.file(
                      File(imagePath),
                      fit: BoxFit.cover,
                    ),
                  )
                : const Icon(LucideIcons.pill, color: Color(0xFF0EA5E9), size: 26),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  med.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: Color(0xFF1E293B),
                  ),
                ),
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0EA5E9).withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(
                      color: const Color(0xFF0EA5E9).withValues(alpha: 0.2),
                    ),
                  ),
                  child: Text(
                    item['time'] as String,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF0EA5E9),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                tooltip: 'Will ring at scheduled time',
                onPressed: () => _onSkipWindow(item),
                icon: const Icon(Icons.cancel, color: Colors.red, size: 30),
                style: IconButton.styleFrom(
                  backgroundColor: Colors.red.withValues(alpha: 0.1),
                  padding: const EdgeInsets.all(8),
                ),
              ),
              const SizedBox(width: 6),
              IconButton(
                tooltip: 'Mark as taken early',
                onPressed: () => _onEarlyTake(item),
                icon: const Icon(Icons.check_circle, color: Colors.green, size: 30),
                style: IconButton.styleFrom(
                  backgroundColor: Colors.green.withValues(alpha: 0.1),
                  padding: const EdgeInsets.all(8),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDueSoonCard(Map<String, dynamic> item) {
    final med = item['medicine'] as Medicine;
    final slotName = item['slotName'] as String? ?? 'Dose';
    final imagePath = med.imagePath;
    final hasImage = imagePath != null && imagePath.isNotEmpty && _existingImagePaths.contains(imagePath);

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: hasImage
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.file(File(imagePath), fit: BoxFit.cover),
                  )
                : const Icon(LucideIcons.pill, color: Colors.white, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  med.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.25),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    slotName,
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                tooltip: 'Skip this dose',
                onPressed: () => _onSkipWindow(item),
                icon: const Icon(Icons.close_rounded, color: Colors.white, size: 24),
                style: IconButton.styleFrom(
                  backgroundColor: Colors.white.withValues(alpha: 0.2),
                  padding: const EdgeInsets.all(6),
                ),
              ),
              const SizedBox(width: 6),
              IconButton(
                tooltip: 'Mark as taken',
                onPressed: () => _onEarlyTake(item),
                icon: const Icon(Icons.check_rounded, color: Colors.white, size: 24),
                style: IconButton.styleFrom(
                  backgroundColor: Colors.white.withValues(alpha: 0.2),
                  padding: const EdgeInsets.all(6),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMixedDueSoonCard(Map<String, dynamic> mixedItem) {
    final type = mixedItem['type'] as String;
    final time = mixedItem['time'] as DateTime;
    final timeFormatted = DateFormat('hh:mm a').format(time);

    String title = '';
    String subtitle = '';
    IconData icon = LucideIcons.bell;
    Color color = Colors.grey;
    Widget? actionButton;

    if (type == 'med') {
      final medData = mixedItem['data'] as Map<String, dynamic>;
      final med = medData['medicine'] as Medicine;
      title = med.name;
      subtitle = 'Dose: ${med.getCurrentDosage(time)}';
      icon = LucideIcons.pill;
      color = const Color(0xFF0EA5E9);
      actionButton = IconButton(
        icon: const Icon(Icons.check_circle, color: Colors.green),
        onPressed: () => _onEarlyTake(medData),
      );
    } else if (type == 'appointment') {
      final appt = mixedItem['data'] as Map<String, dynamic>;
      title = appt['doctor_name'] ?? 'Doctor Appointment';
      subtitle = appt['notes'] ?? 'Scheduled Visit';
      icon = LucideIcons.calendarClock;
      color = Colors.purple;
    } else if (type == 'task') {
      final task = mixedItem['data'] as Map<String, dynamic>;
      title = task['title'] ?? 'Task';
      subtitle = task['description'] ?? 'Family Task';
      icon = LucideIcons.clipboardCheck;
      color = Colors.orange;
    }

    return Container(
      width: 260,
      margin: const EdgeInsets.only(right: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.2)),
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: 0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: color, size: 20),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  timeFormatted,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: color,
                    fontSize: 14,
                  ),
                ),
              ),
              if (actionButton != null) actionButton,
            ],
          ),
          const Spacer(),
          Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF1E293B)),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(color: Colors.grey[600], fontSize: 13),
          ),
        ],
      ),
    );
  }

  Widget _buildStatChip(String label, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.grey[100]!),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.02), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF1E293B))),
              Text(label, style: TextStyle(fontSize: 10, color: Colors.grey[500])),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildProgressCard() {
    final bool hasNoMeds = _allMeds.isEmpty;
    final double progress = hasNoMeds ? 0.0 : (_totalMedsToday == 0 ? 1.0 : _takenMedsToday / _totalMedsToday);
    final int percentage = (progress * 100).toInt();

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.grey[100]!),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.02), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(hasNoMeds ? 'Adherence' : 'Adherence', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.grey[600])),
              Text(hasNoMeds ? '--%' : '$percentage%', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: hasNoMeds ? Colors.grey : const Color(0xFF0EA5E9))),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: LinearProgressIndicator(
              value: progress,
              backgroundColor: (hasNoMeds ? Colors.grey : const Color(0xFF0EA5E9)).withValues(alpha: 0.1),
              valueColor: AlwaysStoppedAnimation<Color>(hasNoMeds ? Colors.grey : const Color(0xFF0EA5E9)),
              minHeight: 10,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            hasNoMeds 
              ? 'Add your medications to track adherence.'
              : (_totalMedsToday == 0 
                ? 'No medications scheduled for today.' 
                : 'You have taken $_takenMedsToday out of $_totalMedsToday medications.'),
            style: TextStyle(fontSize: 12, color: Colors.grey[500]),
          ),
        ],
      ),
    );
  }

  Widget _buildMedicationSummary() {
    if (_nextMedData == null) {
      final hasNoMeds = _allMeds.isEmpty;
      return InkWell(
        onTap: () => widget.onTabChange(1),
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.grey[100]!),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: (hasNoMeds ? Colors.orange : Colors.green).withValues(alpha: 0.1), shape: BoxShape.circle),
                child: Icon(hasNoMeds ? LucideIcons.pill : LucideIcons.check, color: hasNoMeds ? Colors.orange : Colors.green, size: 24),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(hasNoMeds ? 'No medications added' : 'All caught up for today!', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF1E293B))),
                    Text(hasNoMeds ? 'Tap to add your first medicine' : 'Check again later', style: const TextStyle(fontSize: 13, color: Colors.grey)),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.grey),
            ],
          ),
        ),
      );
    }

    return InkWell(
      onTap: () => widget.onTabChange(1),
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 10, offset: const Offset(0, 4))],
          border: Border.all(color: Colors.grey[100]!),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.orange.withValues(alpha: 0.1), shape: BoxShape.circle),
              child: const Icon(LucideIcons.pill, color: Colors.orange, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_nextMedData!['name'] ?? 'Unknown', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF1E293B))),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(LucideIcons.clock, size: 14, color: Colors.grey),
                      const SizedBox(width: 4),
                      Text(_nextMedTimeLabel ?? '--:--', style: const TextStyle(fontSize: 13, color: Colors.grey, fontWeight: FontWeight.w500)),
                      const SizedBox(width: 12),
                      const Icon(LucideIcons.scale, size: 14, color: Colors.grey),
                      const SizedBox(width: 4),
                      Text(_nextMedData!['dosage'] ?? '-', style: const TextStyle(fontSize: 13, color: Colors.grey, fontWeight: FontWeight.w500)),
                    ],
                  ),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.grey),
          ],
        ),
      ),
    );
  }

  Widget _buildNextAppointmentCard() {
    final appt = _nextAppointment!;
    final doctorName = appt['doctor_name'] ?? 'Doctor';
    final apptTime = DateTime.tryParse(appt['appointment_date']?.toString() ?? '')?.toLocal();
    final notes = appt['notes']?.toString() ?? '';
    final dateStr = apptTime != null ? DateFormat('EEE, dd MMM • hh:mm a').format(apptTime) : '';

    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AppointmentScreen())),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2)),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: const Color(0xFFF59E0B).withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(LucideIcons.stethoscope, color: Color(0xFFF59E0B), size: 24),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(doctorName,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Color(0xFF1E293B))),
                  const SizedBox(height: 4),
                  Text(dateStr, style: TextStyle(fontSize: 12, color: Colors.grey[500])),
                  if (notes.isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(notes, maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 12, color: Colors.grey[400])),
                  ],
                ],
              ),
            ),
            Icon(LucideIcons.chevronRight, color: Colors.grey[300], size: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyAppointmentCard() {
    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AppointmentScreen())),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2)),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: const Color(0xFFF59E0B).withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(LucideIcons.calendarPlus, color: Color(0xFFF59E0B), size: 24),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('No upcoming appointments',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Color(0xFF1E293B))),
                  const SizedBox(height: 4),
                  Text('Tap to schedule a doctor visit', style: TextStyle(fontSize: 12, color: Colors.grey[500])),
                ],
              ),
            ),
            Icon(LucideIcons.chevronRight, color: Colors.grey[300], size: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildVitalsSummary() {
    if (_latestVital == null) {
      return InkWell(
        onTap: () => widget.onTabChange(2),
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.grey[100]!),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.blue.withValues(alpha: 0.1), shape: BoxShape.circle),
                child: const Icon(LucideIcons.activity, color: Colors.blue, size: 24),
              ),
              const SizedBox(width: 16),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('No vitals logged yet', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF1E293B))),
                    Text('Tap to log your first reading', style: TextStyle(fontSize: 13, color: Colors.grey)),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.grey),
            ],
          ),
        ),
      );
    }

    String mainLabel = 'Vitals Reading';
    String mainValue = '--';
    IconData mainIcon = LucideIcons.activity;
    Color iconColor = const Color(0xFF0EA5E9);

    if (_latestVital!['bp_systolic'] != null) {
      mainLabel = 'Blood Pressure';
      mainValue = '${_latestVital!['bp_systolic']}/${_latestVital!['bp_diastolic'] ?? '--'} mmHg';
      mainIcon = LucideIcons.activity;
    } else if (_latestVital!['heart_rate'] != null) {
      mainLabel = 'Heart Rate';
      mainValue = '${_latestVital!['heart_rate']} bpm';
      mainIcon = LucideIcons.heart;
      iconColor = Colors.red;
    } else if (_latestVital!['spo2'] != null) {
      mainLabel = 'SpO2';
      mainValue = '${_latestVital!['spo2']}%';
      mainIcon = LucideIcons.droplets;
      iconColor = Colors.blue;
    } else if (_latestVital!['weight'] != null) {
      mainLabel = 'Weight';
      mainValue = '${_latestVital!['weight']} kg';
      mainIcon = LucideIcons.scale;
      iconColor = Colors.green;
    }

    return InkWell(
      onTap: () => widget.onTabChange(2),
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 10, offset: const Offset(0, 4))],
          border: Border.all(color: Colors.grey[100]!),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: iconColor.withValues(alpha: 0.1), shape: BoxShape.circle),
              child: Icon(mainIcon, color: iconColor, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(mainLabel, style: const TextStyle(fontSize: 14, color: Colors.grey, fontWeight: FontWeight.w500)),
                  const SizedBox(height: 2),
                  Text(mainValue, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF1E293B))),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.grey),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickAction(BuildContext context, String label, IconData icon, Color color, VoidCallback onTap) {
    return Column(
      children: [
        InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(20),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Icon(icon, color: color, size: 26),
          ),
        ),
        const SizedBox(height: 8),
        Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Color(0xFF475569))),
      ],
    );
  }
}
